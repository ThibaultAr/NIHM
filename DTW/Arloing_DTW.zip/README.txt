Arloing Thibault
NIHM - DTW


Toute la partie Reconnaissance fonctionne, l'affichage de la forme détectée s'affiche en orange au dessus.
La forme reconnue (textuellement) s'affiche sur la sortie standard (le terminal dans le cas du jar).

Question 5:

La méthode DTW est très éfficace du moment que le geste est effectué dans le bon sens et qu'il est bein orienté. Il faut qu'il soit dans la même orientation et ue le tracé soit dans le même sens que les données de tests.

